import java.util.Scanner;
public class main {
	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
int teste=2;
int x=1;
int y=2;
int b=3;
String bruh="teste teste aaa: ";
while (x<5){
	if (1+1==1+2) {
	if (y==y+1) {
	x=x+1;
}
}
else if (b>1) {
	int tal=2;
for (int i=0;
 (i<5); i++)  {
	x=x+1;
}
}
else {
	teste=3;
}
System.out.println(bruh);
System.out.println(x);
x=x+1;
}
System.out.println("tal tal tal");
x=scanner.nextInt();
System.out.println(x);
	}
}