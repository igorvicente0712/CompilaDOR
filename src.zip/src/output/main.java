import java.util.Scanner;
public class main {
	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
int num=0;
int num2=0;
num=scanner.nextInt();
num2=scanner.nextInt();
int s=num+num2;
System.out.println(s);
	}
}